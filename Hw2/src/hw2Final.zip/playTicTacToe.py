from tictactoe import play

if __name__ == '__main__':
    play()
